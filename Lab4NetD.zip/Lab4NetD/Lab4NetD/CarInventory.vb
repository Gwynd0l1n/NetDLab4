﻿Option Strict On


'' Author Name:    Kyle Edwards
'' Project Name:   Car Inventory Database
'' Date:           07/12/2019
'' Description     This program uses .net to store database info for various vehicles. 
'' 


Public Class frmInventory
    Private carList As New SortedList
    Private currentCarIdentification As String = String.Empty
    Private formEdit As Boolean = False


    Private Sub Reset()

        cbNew.Checked = False
        tbModel.Text = String.Empty
        tbPrice.Text = String.Empty
        cmbMake.SelectedIndex = -1
        cmbYear.SelectedIndex = -1
        lvwCars.Text = String.Empty

    End Sub

    Private Function IsValidInput() As Boolean

        Dim returnValue As Boolean = True
        Dim outputMesssage As String = String.Empty

        If cmbMake.SelectedIndex = -1 Then
            outputMesssage += "Enter Your Vehicles Make"
            returnValue = False
        End If

        If cmbYear.SelectedIndex = -1 Then
            outputMesssage += "Enter Your Vehicles Year"
            returnValue = False
        End If

        If tbModel.Text.Trim.Length = 0 Then
            outputMesssage += "Enter Your Vehicles Model"
            returnValue = False
        End If

        If tbPrice.Text.Trim.Length = 0 Then
            outputMesssage += "Enter The Price Of Your Vehicle"
            returnValue = False
        End If
        Return returnValue

    End Function
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        Dim car As Car
        Dim carItem As ListViewItem

        If IsValidInput() = True Then
            formEdit = True
            lblResults.Text = "Congradulations, Your Vehicle Has Been Registered!"

            If currentCarIdentification.Trim.Length = 0 Then
                car = New Car(cmbMake.Text, cmbYear.Text, tbModel.Text, tbPrice.Text, cbNew.Checked)
                carList.Add(car.IdentificationNumber.ToString(), car)
            Else
                car = CType(carList.Item(currentCarIdentification), Car)
                car.Make = cmbMake.Text
                car.Model = tbModel.Text
                car.Price = tbPrice.Text
                car.Year = cmbYear.Text
                car.News = cbNew.Checked
            End If

            lvwCars.Items.Clear()

            For Each carEntry As DictionaryEntry In carList
                carItem = New ListViewItem()
                car = CType(carEntry.Value, Car)

                carItem.Checked = car.News
                carItem.SubItems.Add(car.IdentificationNumber.ToString())
                carItem.SubItems.Add(car.Make)
                carItem.SubItems.Add(car.Model)
                carItem.SubItems.Add(car.Year)
                carItem.SubItems.Add(car.Price)
                lvwCars.Items.Add(carItem)

            Next carEntry
            Reset()
            formEdit = False

        End If

    End Sub

    Private Sub lvwCars_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvwCars.SelectedIndexChanged

        Const identificationSubItemIndex As Integer = 1

        currentCarIdentification = lvwCars.Items(lvwCars.FocusedItem.Index).SubItems(identificationSubItemIndex).Text

        Dim car As Car = CType(carList.Item(currentCarIdentification), Car)
        cbNew.Checked = car.News
        cmbMake.Text = car.Make
        cmbYear.Text = car.Year
        tbPrice.Text = car.Price
        tbModel.Text = car.Model
        lblResults.Text = car.GetCarInfo()


    End Sub

    Private Sub ToolTip1_Popup(sender As Object, e As PopupEventArgs) Handles ttCarInventory.Popup

    End Sub

    Private Sub CarInventoryForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub cmbMake_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbMake.SelectedIndexChanged

    End Sub
End Class
